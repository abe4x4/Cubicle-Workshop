# Useful Node Links: 
The Cat Shelter App. 

[The Node Event Loops (part of lesson 1)](https://nodejs.dev/learn/the-nodejs-event-loop)

[W3 Node Tutorial/Guide](https://www.w3schools.com/nodejs/default.asp)

[Node Getting Started Guide](https://nodejs.org/docs/latest-v13.x/api/synopsis.html)
